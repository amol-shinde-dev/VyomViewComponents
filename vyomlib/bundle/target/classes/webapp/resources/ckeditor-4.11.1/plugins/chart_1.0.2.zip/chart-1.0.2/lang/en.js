/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'chart', 'en', {
	bar: 'Bar',
	chart: 'Chart',
	chartType: 'Chart type:',
	dialogTitle: 'Edit Chart',
	doughnut: 'Doughnut',
	height: 'Height:',
	label: 'Label:',
	line: 'Line',
	pie: 'Pie',
	polar: 'Polar',
	value: 'Value:'
} );